dependencies ={
    layers:  [
        {
	        name: "../yourCompany/example/exampleRelease.js",
	        dependencies: [
			
				// From testBuildSystemFoo.html
				"dijit.form.Button",
				"dijit.form.Form",
				"dijit.layout.AccordionContainer",
				"dijit.layout.BorderContainer",
				"dijit.layout.ContentPane",
				"dijit.Menu",
				"dojo.data.ItemFileReadStore",
			
				"yourCompany.example.AccordionPane",
				"yourCompany.example.ComboBox"
			]
        }
    ],
    prefixes: [
		[ "dijit", "../dijit" ],
		[ "yourCompany", "../../yourCompany"]
    ]
};
